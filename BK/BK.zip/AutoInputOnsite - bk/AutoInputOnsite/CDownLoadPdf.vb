Imports System.Configuration
Imports System.Text
Imports System.ComponentModel
Imports System.Runtime.InteropServices
Imports System.Threading.Thread

Public Class CDownLoadPdf


    Private Declare Function GetWindowThreadProcessId Lib "user32" (ByVal hWnd As Long, ByVal lpdwProcessId As Long) As Long
    Private Declare Function OpenProcess Lib "kernel32" (ByVal dwDesiredAccess As Long, ByVal bInheritHandle As Long, ByVal dwProcessId As Long) As Long
    Private Declare Function TerminateProcess Lib "kernel32" (ByVal hProcess As Long, ByVal uExitCode As Long) As Long
    Private Declare Function CloseHandle Lib "kernel32" (ByVal hObject As Long) As Long


    Public Function a()

        Try
            '�����ʎ擾����
            Dim childIe = GetPrintPage()
            If childIe IsNot Nothing Then
                Dim rtv As Boolean = GetFcwInfo(childIe, "C:\TOOL\�[���w�芮��\" & Now.ToString("yyyyMMddHHmmss") & ".csv")
                ClosePrintPage()
                Return True
            End If
        Catch ex As Exception

        End Try

    End Function
    '��������擾����
    Function GetFcwInfo(ByVal cIe As SHDocVw.InternetExplorerMedium, ByVal flName As String) As Boolean

        Try
            Dim Action, fcw_formfile, fcw_datafile, url1, url2 As String
            url2 = ""

            Dim form As mshtml.HTMLFormElement

            form = CType(CType(CType(cIe.Document, mshtml.HTMLDocument).body.document, mshtml.HTMLDocument).forms.item(0), mshtml.HTMLFormElement)
            Action = form.action

            If Action = "" Then Return False

            Dim hid_fcw_formfile As mshtml.HTMLInputElement
            hid_fcw_formfile = CType(CType(form.document, mshtml.HTMLDocument).getElementsByName("fcw-formfile").item(0), mshtml.HTMLInputElement)
            fcw_formfile = hid_fcw_formfile.value

            Dim hid_fcw_datafile As mshtml.HTMLInputElement
            hid_fcw_datafile = CType(CType(form.document, mshtml.HTMLDocument).getElementsByName("fcw-datafile").item(0), mshtml.HTMLInputElement)
            fcw_datafile = hid_fcw_datafile.value

            url1 = form.action & "?fcw-driver=FCPC&fcw-formdownload=yes&fcw-newsession=yes&fcw-destination=client&fcw-overlay=3&fcw-endsession=yes&fcw-formfile=" & fcw_formfile & "&fcw-datafile=" & fcw_datafile

            'Print ��ʂ̏��擾
            Dim bodyStr As Object
            Dim bodyTxt As String
            Dim Retrieval As New MSXML2.XMLHTTP
            Retrieval.open("Get", url1, False, "", "")
            Retrieval.send()
            bodyStr = Retrieval.responseBody
            bodyTxt = Retrieval.responseText
            Retrieval = Nothing

            '���[��URL�擾
            Dim reg As New RegularExpressions.Regex("src=""(?<src>[^""]*)""")
            Dim mc As RegularExpressions.MatchCollection = reg.Matches(bodyTxt)
            For Each m As RegularExpressions.Match In mc
                url2 = m.Value
            Next
            url2 = url2.Replace("src", "").Replace("""", "").Replace("=http", "http")
            reg = Nothing

            If System.IO.File.Exists(flName) Then
                FileSystem.Rename(flName.Replace(".csv", ".pdf"), flName.Replace(".csv", "_" & Now.ToString("yyyyMMddHHmmss") & ".bk.pdf"))
            End If

            '���[�쐬
            GetRemoteFiels(url2, flName.Replace(".csv", ".pdf"))

            Return True

        Catch ex As Exception

            Return False

        End Try


    End Function



#Region "SAVE PDF"
    'SAVE PDF
    Function GetRemoteFiels(ByVal RemotePath, ByVal LocalPath) As Boolean

        Dim strBody
        Dim FilePath
        ' On Error Resume Next
        '�擾��
        strBody = GetBody(RemotePath)

        If LocalPath = "" Then
            Return True
        End If
        FilePath = LocalPath
        '�ۑ�����
        If SaveToFile(strBody, FilePath) = True And Err.Number = 0 Then
            GetRemoteFiels = True
            Return True
        Else
            GetRemoteFiels = False
            Return False
        End If

    End Function
    'GetFileName
    Function GetFileName(ByVal RemotePath, ByVal FileName)
        Dim arrTmp
        Dim strFileExt
        arrTmp = Split(RemotePath, ".")
        strFileExt = arrTmp(UBound(arrTmp))
        GetFileName = FileName & "." & strFileExt
    End Function

    'Get Body
    Function GetBody(ByVal url)

        Dim Retrieval As New MSXML2.XMLHTTP
        Retrieval.open("Get", url, False, "", "")
        Retrieval.send()

        GetBody = Retrieval.responseBody
        Retrieval = Nothing

    End Function

    'SaveToFile
    Function SaveToFile(ByVal Stream, ByVal FilePath) As Boolean
        Application.DoEvents()
        ' Try
        Dim objStream

        objStream = CreateObject("ADODB.Stream")
        objStream.Type = 1
        objStream.Open()
        objStream.write(Stream)
        objStream.SaveToFile(FilePath, 2)
        objStream.Close()
        objStream = Nothing
        If Err.Number <> 0 Then
            SaveToFile = False
        Else
            SaveToFile = True
        End If


        Return True

    End Function
#End Region
    ''' <summary>
    ''' �����ʎ擾
    ''' </summary>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Function GetPrintPage() As SHDocVw.InternetExplorerMedium

        Dim ShellWindows As New SHDocVw.ShellWindows

reloIt:

        For Each childIe As SHDocVw.InternetExplorerMedium In ShellWindows

            Com.Sleep5(0)
            System.Windows.Forms.Application.DoEvents()

            If InStr(childIe.FullName.ToLower(), "iexplore.exe") > 0 Then

                Dim url As String = CType(childIe, SHDocVw.InternetExplorerMedium).LocationURL.ToString

                If InStr(url, "/HatKekkaPrint.asp") > 0 AndAlso _
                    InStr(url, "/Redirect.asp") = 0 Then
                    '    If InStr(url, "/HatKekkaPrint.asp") > 0 Then
                    While CType(childIe, SHDocVw.InternetExplorerMedium).ReadyState <> SHDocVw.tagREADYSTATE.READYSTATE_COMPLETE
                        Application.DoEvents()
                        Com.Sleep5(0)
                    End While

                    Try
                        childIe.Stop()
                        childIe.Visible = False
                    Catch ex As Exception

                    End Try

                    ShellWindows = Nothing
                    Return childIe
                ElseIf CType(childIe, SHDocVw.InternetExplorerMedium).LocationURL.Contains("servlet") Then

                    Try
                        childIe.Stop()
                        childIe.GoBack()
                        childIe.Stop()
                        childIe.Visible = False
                    Catch ex As Exception

                    End Try
                    Return childIe
                End If

            End If

        Next



        Return Nothing


    End Function

    ''' <summary>
    ''' ������Close
    ''' </summary>
    ''' <remarks></remarks>
    Sub ClosePrintPage()

        Dim ShellWindows As New SHDocVw.ShellWindows

        Try
            For Each childIe As SHDocVw.InternetExplorerMedium In ShellWindows
                System.Windows.Forms.Application.DoEvents()
                Dim filename As String = System.IO.Path.GetFileNameWithoutExtension(childIe.FullName).ToLower()
                If filename = "iexplore" Then
                    If CType(childIe, SHDocVw.InternetExplorerMedium).LocationURL.Contains("servlet") Then
                        Dim whWnd As Long = childIe.HWND
                        childIe.Quit()
                        KillProcess(whWnd)
                        'childIe.HWND
                        Com.Sleep5(500)
                    ElseIf CType(childIe, SHDocVw.InternetExplorerMedium).LocationURL.Contains("HatKekkaPrint.asp") Then
                        Dim whWnd As Long = childIe.HWND
                        childIe.Quit()
                        KillProcess(whWnd)
                        Com.Sleep5(500)
                    End If
                End If
            Next
        Catch ex As Exception

        End Try
        ShellWindows = Nothing

    End Sub

    Sub CloseChildPage()

        Dim ShellWindows As New SHDocVw.ShellWindows

        Try
            For Each childIe As SHDocVw.InternetExplorerMedium In ShellWindows
                System.Windows.Forms.Application.DoEvents()
                Dim filename As String = System.IO.Path.GetFileNameWithoutExtension(childIe.FullName).ToLower()
                If filename = "iexplore" Then
                    If CType(childIe, SHDocVw.InternetExplorerMedium).LocationURL.Contains("Sougou_Menu.asp") Then
                    Else
                        Dim whWnd As Long = childIe.HWND
                        childIe.Quit()
                        KillProcess(whWnd)
                        Com.Sleep5(500)
                    End If
                End If
            Next
        Catch ex As Exception

        End Try
        ShellWindows = Nothing

    End Sub


    Private Sub KillProcess(ByVal whWnd As Long)
        Dim lpdwProcessId As Long
        Dim hProcessHandle As Long
        GetWindowThreadProcessId(whWnd, lpdwProcessId)
        hProcessHandle = OpenProcess(&H1F0FFF, True, lpdwProcessId)
        Dim success As Long
        If hProcessHandle <> 0 Then
            success = TerminateProcess(hProcessHandle, 0&)
        End If
        If success = 1 Then CloseHandle(hProcessHandle)
    End Sub

End Class
