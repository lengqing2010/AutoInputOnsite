Imports System.ComponentModel
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.Threading.Thread
Imports System.Configuration

Public Class Menu

    Public fra As AutoImportCsv
    Public fra2 As AutoImportNouhinsyo
    Public Ie As SHDocVw.InternetExplorerMedium
    Private WithEvents BackgroundWorker As BackgroundWorker


    Sub CloseIE()
        Try


            Dim wmi = GetObject("winmgmts:\\.")
            Dim pro_s = wmi.instancesof("win32_process")

            For Each p As Object In pro_s
                If p.name = "iexplore.exe" Then p.terminate()
            Next
        Catch ex As Exception

        End Try
    End Sub

    ''' <summary>
    ''' ���o�����׍쐬
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnMs_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMs.Click

        StartAllJunbi()
        DoAutoImportCsv()
        kanryou()
    End Sub

    Private Sub DoAutoImportCsv()
        fra = New AutoImportCsv
        fra.Ie = Ie
        fra.IeVisible = Me.cbWeb.Checked
        If cbHyouji.Checked Then fra.Show()
        fra.DoAll()
        fra.Close()
        pb1.Value = 100
        fra.Dispose()
        fra = Nothing
    End Sub


    ''' <summary>
    ''' �[���w�蔭��
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnNouhin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNouhin.Click

        StartAllJunbi()
        AutoImportNouhinsyo()
      kanryou()
    End Sub
    Private Sub AutoImportNouhinsyo()
        fra2 = New AutoImportNouhinsyo
        fra2.Ie = Ie

        Try
            fra2.IeVisible = Me.cbWeb.Checked

            If cbHyouji.Checked Then
                fra2.Show()
            End If
        Catch ex As Exception

        End Try

        fra2.insatu = Me.cbInsatu.Checked
        fra2.DoAll()
        fra2.Close()
        fra2.Dispose()
        fra2 = Nothing
        pb2.Value = 100
    End Sub

    ''' <summary>
    ''' ���o�����׍쐬  AND  �[���w�蔭��
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAll.Click


        StartAllJunbi()
        DoAutoImportCsv()



        StartAllJunbi()
        Ie = New SHDocVw.InternetExplorerMedium
        AutoImportNouhinsyo()
        kanryou()
    End Sub

    ''' <summary>
    ''' ����
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub kanryou()

        Try
            Ie.Quit()
        Catch ex As Exception

        End Try
        MsgBox("����")
    End Sub

    ''' <summary>
    ''' Start ����
    ''' </summary>
    ''' <remarks></remarks>
    Private Sub StartAllJunbi()



        CloseIE()

re:
        Try
            Ie = Nothing
        Catch ex As Exception
            System.Threading.Thread.Sleep(2000)
            GoTo re
        End Try

        Ie = New SHDocVw.InternetExplorerMedium

        If BackgroundWorker Is Nothing Then
            BackgroundWorker = New BackgroundWorker
            BackgroundWorker.RunWorkerAsync()
        End If



        Timer1.Stop()
        Timer1.Start()

        pb1.Value = 0
        pb2.Value = 0

    End Sub

    ''' <summary>
    ''' Pro bar 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        If fra IsNot Nothing Then
            pb1.Value = fra.ProBar
        End If
        If fra2 IsNot Nothing Then
            pb2.Value = fra2.ProBar
        End If
    End Sub

    ''' <summary>
    ''' Menu_Disposed
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Menu_Disposed(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Disposed
        Try
            Ie.Quit()
        Catch ex As Exception
        End Try
    End Sub

    ''' <summary>
    ''' Menu_Load
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub Menu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            Ie.Quit()
        Catch ex As Exception
        End Try
    End Sub

    ''' <summary>
    ''' Windows Object Something
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub BackgroundWorker_DoWork(ByVal sender As Object, ByVal e As System.ComponentModel.DoWorkEventArgs) Handles BackgroundWorker.DoWork
        Dim com As New Com("")
        com.NewWindowsCom()
    End Sub

End Class