﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;
using System.Configuration;
using AutoInputOnsite;
using Microsoft.VisualBasic;
namespace AutoInputOnsite
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }
        public AutoImportCsv fra;
        public AutoImportNouhinsyo fra2;
        public SHDocVw.InternetExplorerMedium Ie;
        private BackgroundWorker BackgroundWorker;
        public void CloseIE()
        {
            try
            {
                System.Diagnostics.Process[] myProcesses;
                myProcesses = System.Diagnostics.Process.GetProcessesByName("IEXPLORE");
                foreach (System.Diagnostics.Process instance in myProcesses)
                {
                    instance.CloseMainWindow();
                }
            }
            catch (Exception)
            {
            }
        }
        private void DoAutoImportCsv()
        {
            fra = new AutoImportCsv();
            fra.Ie = Ie;
            fra.IeVisible = this.cbWeb.Checked;
            if (cbHyouji.Checked)
            {
                fra.Show();
            }
            fra.DoAll();
            fra.Close();
            pb1.Value = 100;
            fra.Dispose();
            fra = null;
        }
        /// <summary>
        /// 納期指定発注
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <remarks></remarks>
        private void btnNouhin_Click(System.Object sender, System.EventArgs e)
        {
            StartAllJunbi();
            AutoImportNouhinsyo();
            kanryou();
        }
        private void AutoImportNouhinsyo()
        {
            fra2 = new AutoImportNouhinsyo();
            fra2.Ie = Ie;
            try
            {
                fra2.IeVisible = this.cbWeb.Checked;
                if (cbHyouji.Checked)
                {
                    fra2.Show();
                }
            }
            catch (Exception)
            {
            }
            fra2.insatu = this.cbInsatu.Checked;
            fra2.DoAll();
            fra2.Close();
            fra2.Dispose();
            fra2 = null;
            pb2.Value = 100;
        }
        /// <summary>
        /// 見出＆明細作成  AND  納期指定発注
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <remarks></remarks>
        private void btnAll_Click_1(System.Object sender, System.EventArgs e)
        {
            //見出＆明細作成
            StartAllJunbi();
            DoAutoImportCsv();
            //納期指定発注
            StartAllJunbi();
            pb1.Value = 100;
            AutoImportNouhinsyo();
            kanryou();
        }
        /// <summary>
        /// 完了
        /// </summary>
        /// <remarks></remarks>
        private void kanryou()
        {
            try
            {
                Ie.Quit();
            }
            catch (Exception)
            {
            }
            MessageBox.Show("完了");
        }
        /// <summary>
        /// Start 準備
        /// </summary>
        /// <remarks></remarks>
        private void StartAllJunbi()
        {
            CloseIE();
        re:
            try
            {
                Ie = null;
            }
            catch (Exception)
            {
                System.Threading.Thread.Sleep(2000);
                goto re;
            }
            Ie = new SHDocVw.InternetExplorerMedium();
            if (ReferenceEquals(BackgroundWorker, null))
            {
                BackgroundWorker = new BackgroundWorker();
                BackgroundWorker.DoWork += BackgroundWorker_DoWork;
                BackgroundWorker.RunWorkerAsync();
            }
            else
            {
                if (!BackgroundWorker.IsBusy)
                {
                    BackgroundWorker.RunWorkerAsync();
                }
                else
                {
                    BackgroundWorker.Dispose();
                    BackgroundWorker = new BackgroundWorker();
                    BackgroundWorker.DoWork += BackgroundWorker_DoWork;
                    BackgroundWorker.RunWorkerAsync();
                }
                //BackgroundWorker.Dispose()
            }
            Timer1.Stop();
            Timer1.Start();
            pb1.Value = 0;
            pb2.Value = 0;
        }
        /// <summary>
        /// Pro bar
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <remarks></remarks>
        private void Timer1_Tick_1(System.Object sender, System.EventArgs e)
        {
            if (fra != null)
            {
                pb1.Value = fra.ProBar;
            }
            if (fra2 != null)
            {
                pb2.Value = fra2.ProBar;
            }
        }
        /// <summary>
        /// Menu_Disposed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <remarks></remarks>
        private void Menu_Disposed(object sender, System.EventArgs e)
        {
            try
            {
                Ie.Quit();
            }
            catch (Exception)
            {
            }
        }
        /// <summary>
        /// Menu_Load
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <remarks></remarks>
        private void Menu_Load(System.Object sender, System.EventArgs e)
        {
            try
            {
                Ie.Quit();
            }
            catch (Exception)
            {
            }
        }
        /// <summary>
        /// Windows Object Something
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <remarks></remarks>
        private void BackgroundWorker_DoWork(object sender, System.ComponentModel.DoWorkEventArgs e)
        {
            Com com = new Com("");
            com.NewWindowsCom();
        }
        /// <summary>
        /// 見出＆明細作成
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <remarks></remarks>
        private void btnMs_Click_1(object sender, EventArgs e)
        {
            StartAllJunbi();
            DoAutoImportCsv();
            kanryou();
        }
    }
}