Public Class PARAM

    Public Ie As SHDocVw.InternetExplorerMedium
    Public csvFileName As String

End Class
