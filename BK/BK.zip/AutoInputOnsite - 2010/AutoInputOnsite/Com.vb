Imports System.Configuration
Imports System.Text
Imports System.ComponentModel
Imports System.Runtime.InteropServices
Imports System.Threading.Thread
'Imports Windows.Forms.Application

Public Class Com

#Region "Windows DLL"
    Public Declare Function timeGetTime Lib "winmm.dll" () As Long
    Public Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> Public Shared Function FindWindow(ByVal lpClassName As String, ByVal lpWindowName As String) As IntPtr
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> Private Shared Function FindWindowEx( _
        ByVal parentHandle As IntPtr, _
        ByVal childAfter As IntPtr, _
        ByVal lclassName As String, _
        ByVal windowTitle As String) As IntPtr
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> Private Shared Function SendMessage( _
        ByVal hWnd As IntPtr, _
        ByVal Msg As Integer, _
        ByVal wParam As Integer, _
        ByVal lParam As StringBuilder) As Integer
    End Function

    <DllImport("user32.dll", CharSet:=CharSet.Auto, SetLastError:=True)> Private Shared Function IsWindowVisible( _
        ByVal hWnd As IntPtr) As Boolean
    End Function

    Private Enum WM As Integer
        SETTEXT = &HC
    End Enum

    Private Enum BM As Integer
        CLICK = &HF5
    End Enum

#End Region


#Region "Sleep���@"

    ''' <summary>
    ''' ����Sleep ����d�l����
    ''' </summary>
    ''' <param name="Interval"></param>
    ''' <remarks></remarks>
    Public Shared Sub Sleep5(ByVal Interval As Integer)
        Dim __time As DateTime = DateTime.Now
        Dim __Span As Int64 = Interval * 10000
        While (DateTime.Now.Ticks - __time.Ticks < __Span)
            Application.DoEvents()
            System.Threading.Thread.Sleep(0)
        End While
    End Sub

#End Region


    Public folder_Hattyuu As String = ConfigurationManager.AppSettings("Folder_Hattyuu").ToString()
    Public folder_Hattyuu_kanryou As String = ConfigurationManager.AppSettings("Folder_Hattyuu_kanryou").ToString()
    Public folder_Nouki As String = ConfigurationManager.AppSettings("Folder_Nouki").ToString()
    Public folder_Nouki_kanryou As String = ConfigurationManager.AppSettings("Folder_Nouki_kanryou").ToString()
    Public user As String = ConfigurationManager.AppSettings("User").ToString()
    Public password As String = ConfigurationManager.AppSettings("Password").ToString()
    Public url As String = ConfigurationManager.AppSettings("PasswordNyuuryoku").ToString()
    Public pdfPath As String = ConfigurationManager.AppSettings("Pdf_Path").ToString()

    Public logFileName As String
    Public file_list_hattyuu As List(Of String)
    Public file_list_Nouki As List(Of String)

    Public IsDebug As Boolean = (ConfigurationManager.AppSettings("Debug").ToString().ToUpper = "TRUE")


    ''' <summary>
    ''' INIT
    ''' </summary>
    ''' <param name="inLogFileName"></param>
    ''' <remarks></remarks>
    Public Sub New(ByVal inLogFileName As String)

        logFileName = inLogFileName

        If user = "" Then user = "china\shil2"
        If password = "" Then password = "qwer@123"

        '�t�H���_�ǂ�
        '����
        If Not System.IO.Directory.Exists(folder_Hattyuu) Then
            My.Computer.FileSystem.CreateDirectory(folder_Hattyuu)
        End If

        If Not System.IO.Directory.Exists(folder_Hattyuu_kanryou) Then
            My.Computer.FileSystem.CreateDirectory(folder_Hattyuu_kanryou)
        End If
        '�[��
        If Not System.IO.Directory.Exists(folder_Nouki) Then
            My.Computer.FileSystem.CreateDirectory(folder_Nouki)
        End If

        If Not System.IO.Directory.Exists(folder_Nouki_kanryou) Then
            My.Computer.FileSystem.CreateDirectory(folder_Nouki_kanryou)
        End If
        'PDF
        If Not System.IO.Directory.Exists(pdfPath) Then
            My.Computer.FileSystem.CreateDirectory(pdfPath)
        End If

        file_list_hattyuu = GetAllFiles(folder_Hattyuu, "*.csv")
        file_list_Nouki = GetAllFiles(folder_Nouki, "*.csv")

    End Sub



    ''' <summary>
    ''' Window Form �����ǉ����e
    ''' </summary>
    ''' <remarks></remarks>
    Public Sub NewWindowsCom()

        user = ConfigurationManager.AppSettings("User").ToString()
        password = ConfigurationManager.AppSettings("Password").ToString()
        If user = "" Then user = "china\shil2"
        If password = "" Then password = "qwer@123"

        Dim hatyuu_list_idx As Integer = 0
        Dim nouki_list_idx As Integer = 0

        Dim hWnd As IntPtr
        Do While hWnd = IntPtr.Zero

            System.Threading.Thread.Sleep(0)

            '�F�؏��
            If hWnd = IntPtr.Zero Then
                hWnd = FindWindow("#32770", "windows �Z�L�����e�B")
                If hWnd <> IntPtr.Zero Then
                    NewNinnsyou(hWnd)
                End If
                hWnd = IntPtr.Zero
            End If

            '�t�@�C���A�b�v���[�h
            If hWnd = IntPtr.Zero Then
                hWnd = FindWindow("#32770", "�A�b�v���[�h����t�@�C���̑I��")
                If hWnd <> IntPtr.Zero Then
                    NewFileSantaku(hWnd, file_list_hattyuu(hatyuu_list_idx))
                    hatyuu_list_idx += 1
                End If

                hWnd = IntPtr.Zero
            End If


            ''�v���O�������I�����܂�
            'If hWnd = IntPtr.Zero Then
            '    hWnd = FindWindow("#32770", "Internet Explorer")
            '    If hWnd <> IntPtr.Zero Then
            '        NewStopErrDg(hWnd)
            '    End If
            '    hWnd = IntPtr.Zero
            'End If

            System.Windows.Forms.Application.DoEvents()
            Sleep5(10)

        Loop

    End Sub




    ''' <summary>
    ''' �F�� Win7
    ''' </summary>
    ''' <param name="hWnd"></param>
    ''' <remarks></remarks>
    Public Sub NewNinnsyou(ByVal hWnd As IntPtr)
        Dim DirectUIHWND As IntPtr = FindWindowEx(hWnd, IntPtr.Zero, "DirectUIHWND", String.Empty)
        Dim CtrlNotifySink1 As IntPtr = FindWindowEx(DirectUIHWND, IntPtr.Zero, "CtrlNotifySink", String.Empty)
        Dim CtrlNotifySink2 As IntPtr = FindWindowEx(DirectUIHWND, CtrlNotifySink1, "CtrlNotifySink", String.Empty)
        Dim CtrlNotifySink3 As IntPtr = FindWindowEx(DirectUIHWND, CtrlNotifySink2, "CtrlNotifySink", String.Empty)
        Dim CtrlNotifySink4 As IntPtr = FindWindowEx(DirectUIHWND, CtrlNotifySink3, "CtrlNotifySink", String.Empty)
        Dim CtrlNotifySink5 As IntPtr = FindWindowEx(DirectUIHWND, CtrlNotifySink4, "CtrlNotifySink", String.Empty)
        Dim CtrlNotifySink6 As IntPtr = FindWindowEx(DirectUIHWND, CtrlNotifySink5, "CtrlNotifySink", String.Empty)
        Dim CtrlNotifySink7 As IntPtr = FindWindowEx(DirectUIHWND, CtrlNotifySink6, "CtrlNotifySink", String.Empty)
        Dim CtrlNotifySink8 As IntPtr = FindWindowEx(DirectUIHWND, CtrlNotifySink7, "CtrlNotifySink", String.Empty)
        Dim hEdit As IntPtr = FindWindowEx(CtrlNotifySink7, IntPtr.Zero, "Edit", String.Empty)
        SendMessage(hEdit, WM.SETTEXT, 0, New StringBuilder(user))
        Dim hEdit1 As IntPtr = FindWindowEx(CtrlNotifySink8, IntPtr.Zero, "Edit", String.Empty)
        SendMessage(hEdit1, WM.SETTEXT, 0, New StringBuilder(password))
        Dim hEdit2 As IntPtr = FindWindowEx(CtrlNotifySink3, IntPtr.Zero, "Button", "OK")
        SendMessage(hEdit2, BM.CLICK, 0, Nothing)
    End Sub

    ''' <summary>
    ''' �t�@�C���I��
    ''' </summary>
    ''' <param name="hWnd"></param>
    ''' <param name="fileName"></param>
    ''' <remarks></remarks>
    Public Sub NewFileSantaku(ByVal hWnd As IntPtr, ByVal fileName As String)

        Sleep5(200)
reFind:
        '����ꍇ�A�ႤFORM Finded
        If FindWindowEx(hWnd, IntPtr.Zero, "ComboBoxEx32", String.Empty) = IntPtr.Zero Then
            hWnd = FindWindow("#32770", "�A�b�v���[�h����t�@�C���̑I��")
        End If


        Dim hComboBoxEx As IntPtr = FindWindowEx(hWnd, IntPtr.Zero, "ComboBoxEx32", String.Empty)
        Dim hComboBox As IntPtr = FindWindowEx(hComboBoxEx, IntPtr.Zero, "ComboBox", String.Empty)
        Dim hEdit As IntPtr = FindWindowEx(hComboBox, IntPtr.Zero, "Edit", String.Empty)

        Do Until IsWindowVisible(hEdit)
            Sleep5(1)
            GoTo reFind
        Loop

        SendMessage(hEdit, WM.SETTEXT, 0, New StringBuilder(folder_Hattyuu & fileName))
        Dim hButton As IntPtr = FindWindowEx(hWnd, IntPtr.Zero, "Button", "�J��(&O)")
        SendMessage(hButton, BM.CLICK, 0, Nothing)

    End Sub

   

    'MESSAGE �ǉ�
    Public Sub AddMsg(ByVal msg As String)
        If IsDebug Then
            WriteLog(Now.ToString("yy/MM/dd HH:mm:ss") & "��:" & msg, logFileName)
        End If
    End Sub

    '���O�o��
    Private Sub WriteLog(ByVal Msg As String, ByVal tmpfileName As String)
        Dim varAppPath As String
        varAppPath = System.AppDomain.CurrentDomain.SetupInformation.ApplicationBase + "log"
        System.IO.Directory.CreateDirectory(varAppPath)
        Dim head As String
        head = System.DateTime.Now.Hour.ToString() + ":" + System.DateTime.Now.Minute.ToString()
        Msg = head + System.Environment.NewLine + Msg + System.Environment.NewLine
        Dim strFile As String
        strFile = varAppPath + "\" + tmpfileName + ".log"
        Dim SW As System.IO.StreamWriter
        SW = New System.IO.StreamWriter(strFile, True)
        SW.WriteLine(Msg)
        SW.Flush()
        SW.Close()
    End Sub

    '�t�@�C���擾
    Private Function GetAllFiles(ByVal strDirect As String, ByVal exName As String) As List(Of String)

        Dim flList As New List(Of String)

        If Not (strDirect Is Nothing) Then
            Dim mFileInfo As System.IO.FileInfo
            Dim mDirInfo As New System.IO.DirectoryInfo(strDirect)
            Try
                For Each mFileInfo In mDirInfo.GetFiles(exName)
                    flList.Add(mFileInfo.Name)
                Next
            Catch ex As System.IO.DirectoryNotFoundException

            End Try
        End If

        Return flList

    End Function

    'Get Frame
    Public Function GetFrameByName(ByRef WebOrWindow As SHDocVw.InternetExplorerMedium, ByVal name As String) As mshtml.HTMLWindow2

        SleepAndWaitComplete(WebOrWindow)

        Try
            Dim Doc As mshtml.HTMLDocument = CType(WebOrWindow.Document, mshtml.HTMLDocument)

            Dim length As Integer = Doc.frames.length
            Dim frames As mshtml.FramesCollection = Doc.frames

            Dim frm As mshtml.HTMLWindow2
            'Object �K�v�A frames.item(i) i��Inertger�� �G���[
            Dim i As Object

            For i = 0 To length - 1
                'frm = 
                If CType(frames.item(i), mshtml.HTMLWindow2).name = name Then
                    Return CType(frames.item(i), mshtml.HTMLWindow2)
                End If
            Next

            Dim wd As Object
            For i = 0 To length - 1
                frm = CType(frames.item(i), mshtml.HTMLWindow2)
                wd = GetFrameByName(frm, name)
                If wd IsNot Nothing Then
                    Return CType(wd, mshtml.HTMLWindow2)
                End If
            Next
        Catch ex As Exception

        End Try
        Return Nothing
    End Function

    'Get Frame
    Public Function GetFrameByName(ByRef webApp As mshtml.HTMLWindow2, ByVal name As String) As mshtml.HTMLWindow2
        Dim Doc As mshtml.HTMLDocument = CType(webApp.document, mshtml.HTMLDocument)
        Dim length As Integer = Doc.frames.length
        Dim frames As mshtml.FramesCollection = Doc.frames
        Dim i As Object
        For i = 0 To length - 1
            Dim frm As mshtml.HTMLWindow2 = CType(frames.item(i), mshtml.HTMLWindow2)
            If frm.name = name Then
                Return frm
            End If
        Next

        For i = 0 To length - 1
            Dim frm As mshtml.HTMLWindow2 = CType(frames.item(i), mshtml.HTMLWindow2)
            Dim wd As Object = GetFrameByName(frm, name)
            If wd IsNot Nothing Then
                Return CType(wd, mshtml.HTMLWindow2)
            End If
        Next

        Return Nothing

    End Function

    'Sleep App
    Sub SleepAndWaitComplete(ByRef webApp As SHDocVw.InternetExplorerMedium, Optional ByVal tmOut As Integer = 100)

        Sleep5(100)

        For i As Integer = 0 To 10

            Do Until webApp.ReadyState = WebBrowserReadyState.Complete AndAlso Not webApp.Busy

                System.Windows.Forms.Application.DoEvents()
                Sleep5(tmOut / 10)
                i = 0
            Loop

            Do Until CType(webApp.Document, mshtml.HTMLDocument).readyState.ToLower = "complete"
                System.Windows.Forms.Application.DoEvents()
                Sleep5(tmOut / 10)
                i = 0
            Loop

            Try
                Dim Doc As mshtml.HTMLDocument = CType(webApp.Document, mshtml.HTMLDocument)
                Dim length As Integer = Doc.frames.length
                Dim frames As mshtml.FramesCollection = Doc.frames
                For j As Integer = 0 To length - 1
                    Dim frm As mshtml.HTMLWindow2 = CType(frames.item(j), mshtml.HTMLWindow2)
                    Do Until frm.document.readyState.ToLower = "complete"
                        System.Windows.Forms.Application.DoEvents()
                        Sleep5(1)
                    Loop
                Next
            Catch ex As Exception

            End Try

        Next

    End Sub

    'Get element and do soming
    Public Function GetElementByDo(ByRef webApp As SHDocVw.InternetExplorerMedium, ByVal fraName As String, ByVal tagName As String, ByVal keyName As String, ByVal keyTxt As String) As mshtml.IHTMLElement

        If webApp Is Nothing Then
            Return Nothing
        End If
        SleepAndWaitComplete(webApp)
        Dim Doc As mshtml.HTMLDocument = CType(webApp.Document, mshtml.HTMLDocument)
        Dim eles As mshtml.IHTMLElementCollection
        If fraName = "" Then
            eles = Doc.getElementsByTagName(tagName)
        Else
            Dim fra As mshtml.HTMLWindow2 = GetFrameWait(webApp, fraName)

            Doc = CType(fra.document, mshtml.HTMLDocument)
            eles = Doc.getElementsByTagName(tagName)
        End If

        SleepAndWaitComplete(webApp)
        For Each ele As mshtml.IHTMLElement In eles
            Try
                If keyName = "innertext" Then
                    If ele.innerText = keyTxt Then
                        Return ele
                    End If
                Else
                    If ele.getAttribute(keyName).ToString = keyTxt Then
                        Return ele
                    End If
                End If

            Catch ex As Exception
            End Try
        Next
        Return Nothing

    End Function

    'Get Frame
    Public Function GetFrameWait(ByRef webApp As SHDocVw.InternetExplorerMedium, ByVal name As String) As mshtml.HTMLWindow2

        Dim fra As mshtml.HTMLWindow2

        For i As Integer = 1 To 10
            fra = GetFrameByName(webApp, name)
            If fra IsNot Nothing Then
                Return fra
            End If
            Sleep5(200)
        Next

        Return Nothing

    End Function

    'Get Element
    Public Function GetElementBy(ByRef webApp As SHDocVw.InternetExplorerMedium, ByVal fraName As String, ByVal tagName As String, ByVal keyName As String, ByVal keyTxt As String) As mshtml.IHTMLElement

        SleepAndWaitComplete(webApp)

        Try
            While GetElementByDo(webApp, fraName, tagName, keyName, keyTxt) Is Nothing
                System.Windows.Forms.Application.DoEvents()
                Sleep5(1)
            End While

            Return GetElementByDo(webApp, fraName, tagName, keyName, keyTxt)
        Catch ex As Exception
            Return GetElementByDo(webApp, fraName, tagName, keyName, keyTxt)
        End Try

    End Function

    ''' <summary>
    ''' GetElement
    ''' </summary>
    ''' <param name="fra"></param>
    ''' <param name="tagName"></param>
    ''' <param name="keyName"></param>
    ''' <param name="keyTxt"></param>
    ''' <returns></returns>
    ''' <remarks></remarks>
    Public Function GetElement(ByVal fra As mshtml.HTMLWindow2, ByVal tagName As String, ByVal keyName As String, ByVal keyTxt As String) As mshtml.IHTMLElement

        Dim eles As mshtml.IHTMLElementCollection
        Dim Doc As mshtml.HTMLDocument
        Doc = CType(fra.document, mshtml.HTMLDocument)


        eles = Doc.getElementsByTagName(tagName)
        For Each ele As mshtml.IHTMLElement In eles
            Try
                If keyName = "innertext" Then
                    If ele.innerText = keyTxt Then
                        Return ele
                    End If
                Else
                    If ele.getAttribute(keyName).ToString = keyTxt Then
                        Return ele
                    End If
                End If

            Catch ex As Exception
            End Try
        Next
        Return Nothing

    End Function

End Class
